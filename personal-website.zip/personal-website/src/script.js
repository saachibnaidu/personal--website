const apiUrl = "https://api.jsonbin.io/v3/b/673bf373acd3cb34a8aad03e";
const database = document.getElementById("db");

const getDB = async () => {
  const response = await fetch(apiUrl + "/latest" , {
    method: "GET",
    headers: {
      //"Content-Type": "application/json",
      "X-Master-Key": "$2a$10$TI5HbdDry4ZdNwfzSPVs3uUx4P3LdrKN.GrvYpJFZHaDKb3ILKCGS"
    }
  });
  const db = await response.json;
  console.log(db.record);
  return db.record;
}

const renderDB = (db) => {
  while(database.firstChild){
    database.removeChild(database.firstChild);
  }
  console.log(db.projects[0].name);
  db.projects.forEach((project)=>{
    let item = document.createElement("div");
    let name = document.createElement("div");
    name.innerHTML = project.name;
    let description = document.createElement("div");
    description.innerHTML = project.desc;
    let url = document.createElement("div");
    url.innerHTML = project.url;
    item.appendChild(name);
    item.appendChild(description);
    item.appendChild(url);
    database.appendChild(item);
  });
}

getDB().then((db) => {
  renderDB(db);
});